this["JST"] = this["JST"] || {};

this["JST"]["createEvent"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<p><input type="text" id="eventTitle" /></p>\n<p><input type="time" id="eventStartTime" /></p>\n<p><input type="time" id="eventEndTime" /></p>\n<p><button> Create Event </button> </p>\n<p class="error"></p>\n';

}
return __p
};

this["JST"]["day"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<h1> ' +
((__t = ( date )) == null ? '' : __t) +
' </h1>\n<p class=\'back\'> &larr; Back to Month View </p>\n<div class="splitView">\n</div>\n';

}
return __p
};

this["JST"]["dayCell"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<span class="date">' +
((__t = (num)) == null ? '' : __t) +
'</span>\n<ul>\n    ';
 titles.forEach(function (title) { ;
__p += '\n        <li>' +
((__t = ( title )) == null ? '' : __t) +
'</li>\n    ';
 }); ;
__p += '\n</ul>\n';

}
return __p
};

this["JST"]["dayTable"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<thead>\n    <tr>\n        <th> Time </th>\n        <th> Event </th>\n    </tr>\n</thead>\n<tbody>\n\n</tbody>\n';

}
return __p
};

this["JST"]["details"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<h2>' +
((__t = ( title )) == null ? '' : __t) +
'</h2>\n';
 if (start) { ;
__p += '\n<p> ' +
((__t = ( start )) == null ? '' : __t) +
' - ' +
((__t = ( end )) == null ? '' : __t) +
' (' +
((__t = ( duration )) == null ? '' : __t) +
') <p>\n<p> <button> Delete Event </button>\n';
 } ;
__p += '\n';

}
return __p
};

this["JST"]["hour"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<td class=\'time\'> ' +
((__t = ( time )) == null ? '' : __t) +
'</td>\n<td class=\'event\'></td>\n';

}
return __p
};

this["JST"]["month"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<h1>\n<span class="prev"> &larr; Previous Month </span> \n' +
((__t = (name)) == null ? '' : __t) +
' ' +
((__t = (year)) == null ? '' : __t) +
'\n<span class="next"> Next Month &rarr; </span>\n</h1>\n<table class=\'month\'>\n<thead>\n    <tr>\n        <th>Sunday</th>\n        <th>Monday</th>\n        <th>Tuesday</th>\n        <th>Wednesday</th>\n        <th>Thursday</th>\n        <th>Friday</th>\n        <th>Saturday</th>\n    </tr>\n</thead>\n<tbody>\n</tbody>\n</table>\n';

}
return __p
};