this["JST"] = this["JST"] || {};

this["JST"]["controls"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<li><a href="/create"> Create Event </a></li>';

}
return __p
};

this["JST"]["createEvent"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="modal-dialog">\n<div class="modal-content">\n<div class="modal-header">\n<button class="close">&times;</button>\n<h4 class="modal-title"> Create New Event </h4>\n</div>\n<div class="modal-body">\n<form>\n<label>Title</label>\n<input type="text" class="form-control" id="title" />\n<label>Details</label>\n<textarea id="details"  class="form-control"></textarea>\n<label>Date</label>\n<input type="datetime-local" class="form-control" id="date" />    \n</form>\n</div>\n<div class="modal-footer">\n<a href="#" class="modify btn btn-primary"> Create Event </a>\n</div>\n</div>\n</div>';

}
return __p
};

this["JST"]["event"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<td>' +
((__t = (id)) == null ? '' : __t) +
'</td>\n<td>' +
((__t = (title)) == null ? '' : __t) +
'</td>\n<td>' +
((__t = (details)) == null ? '' : __t) +
'</td>\n<td>' +
((__t = (date)) == null ? '' : __t) +
'</td>\n<td>' +
((__t = (createdOn)) == null ? '' : __t) +
'</td>\n<td>\n    <button class="edit btn btn-inverse">\n        <span class="glyphicon glyphicon-edit glyphicon-white"></span>\n    </button>\n    <button class="delete btn btn-danger">\n        <span class="glyphicon glyphicon-trash"></span>\n    </button>\n</td>';

}
return __p
};

this["JST"]["events"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<thead>\n    <tr>\n        <th data-field="id">ID</th>\n        <th data-field="title">Title</th>\n        <th data-field="details">Details</th>\n        <th data-field="date">Date</th>\n        <th data-field="createdOn">Created On</th>\n        <th> Actions </th>\n    </tr>\n</thead>\n<tbody></tbody>';

}
return __p
};

this["JST"]["modifyEvent"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="modal-dialog">\n    <div class="modal-content">\n        <div class="modal-header">\n            <button class="close">&times;</button>\n            <h4 class="modal-title"> ' +
((__t = ( heading )) == null ? '' : __t) +
' </h4>\n        </div>\n        <div class="modal-body">\n        <form>\n            <label>Title</label>\n            <input type="text" class="form-control" id="title" value="' +
((__t = (title)) == null ? '' : __t) +
'" />\n            <label>Details</label>\n            <textarea id="details"  class="form-control">' +
((__t = (details)) == null ? '' : __t) +
'</textarea>\n            <label>Date</label>\n            <input type="datetime-local" class="form-control" id="date" value="' +
((__t = (date)) == null ? '' : __t) +
'" />    \n        </form>\n        </div>\n        <div class="modal-footer">\n            <a href="#" class="modify btn btn-primary"> ' +
((__t = (btnText)) == null ? '' : __t) +
' </a>\n        </div>\n    </div>\n</div>';

}
return __p
};